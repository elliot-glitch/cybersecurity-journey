# Nmap Cheat Sheet

## Basic Scans
- `nmap target`
- `nmap -sS -p- target`

## Version Detection
- `nmap -sV target`

## Script Scanning
- `nmap -sC target`
