# Networking Notes

## OSI Model
- Layer 1: Physical
- Layer 2: Data Link
- Layer 3: Network
...

## TCP/IP Model
- Application
- Transport
- Internet
- Network Access
