# TryHackMe – Nmap Room

## Commands Used
- `nmap -sS -p- target`
- `nmap -sV target`

## Key Takeaways
- Use `-Pn` to skip ping
- `-sC` runs default scripts
